//
//  recipeCardView.swift
//  zest
//
//  Created by Yuet Yu Melody Lam  on 4/29/20.
//  Copyright © 2020 Yuet Yu Melody Lam . All rights reserved.
//

import UIKit

class recipeCardView: UIView {
    
    @IBOutlet weak var containerView: UIView!
    
    @IBOutlet weak var recipeName: UILabel!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
