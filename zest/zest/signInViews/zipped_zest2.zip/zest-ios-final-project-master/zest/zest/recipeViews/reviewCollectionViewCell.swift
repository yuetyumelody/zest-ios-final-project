//
//  reviewCollectionViewCell.swift
//  zest
//
//  Created by Yuet Yu Melody Lam  on 4/29/20.
//  Copyright © 2020 Yuet Yu Melody Lam . All rights reserved.
//

import UIKit

class reviewCollectionViewCell: UICollectionViewCell {
    
    
}
