//
//  CollectionViewCell.swift
//  zest
//
//  Created by Yuet Yu Melody Lam  on 4/29/20.
//  Copyright © 2020 Yuet Yu Melody Lam . All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var reviewContent: UILabel!
    @IBOutlet weak var reviewer: UILabel!
}
