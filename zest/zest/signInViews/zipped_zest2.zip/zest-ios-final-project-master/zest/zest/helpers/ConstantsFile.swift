//
//  ConstantsFile.swift
//  zest
//
//  Created by Rohit Sai Gopal on 5/2/20.
//  Copyright © 2020 Yuet Yu Melody Lam . All rights reserved.
//

import Foundation

struct Constants{
    struct Storyboard{
        static let homeviewcontroller = "HomeVC"
    }
}
