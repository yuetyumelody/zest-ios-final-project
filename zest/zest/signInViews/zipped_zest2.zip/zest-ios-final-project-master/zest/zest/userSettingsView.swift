//
//  userSettingsView.swift
//  zest
//
//  Created by Rohit Sai Gopal on 5/3/20.
//  Copyright © 2020 Yuet Yu Melody Lam . All rights reserved.
//  MOSTLY WORKS, JUST GOTTA DISPLAY ALL THE INFORMATION AND TRANSITION TO ANOTHER SCREEN ONCE THE UPDATE BUTTON IS CLICKED

import UIKit
import FirebaseAuth
import Firebase
import FirebaseFirestore

class userSettingsView: UIViewController {
    @IBOutlet weak var profilPic: UIImageView!
    @IBOutlet weak var firstnameField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var lastNameField: UITextField!
    
        @IBOutlet weak var updateButton: UIButton!
    let user = Auth.auth().currentUser
    override func viewDidLoad() {
         
               let email = user?.email
               let db = Firestore.firestore()
               let docRef = db.collection("Users").document(email!) //using email to find our user

                      docRef.getDocument { (document, error) in
                          if let document = document, document.exists {
                              let dataDescription = document.data().map(String.init(describing:)) ?? "nils"
                              print("Document data: \(dataDescription)")
                           print(type(of: dataDescription))
                           
                           self.emailField.text =  email
            //             self.firstnameField =
            //             self.lastNameField =
            //             self.passwordField =
            //             self.profilePic = 
                          } else {
                              print("Document does not exist")
                          }
                      }
        
        setUpElements()
        // Do any additional setup after loading the view.
        
    }

    @IBAction func updateAction(_ sender: Any) {
        let email = user?.email
        Auth.auth().currentUser?.updateEmail(to: emailField.text!) { (error) in
          // ...
        }
        Auth.auth().currentUser?.updatePassword(to: passwordField.text!) { (error) in
          // ...
        }
        let db = Firestore.firestore()
        db.collection("Users").document(email!).setData(["firstname" : firstnameField.text, "lastname" : lastNameField.text , "email" : emailField.text , "usernname" : usernameField.text, "password" : passwordField.text], merge: true) { (err) in
            if err != nil{
                
                self.transitionToHome()    // hasnt been implemented yet
            }
            else{
                print("There has been an error, please make sure all the fields are filled")
            }
        }
    }
    
    func setUpElements(){
        Utilities.styleTextField(firstnameField)
        Utilities.styleTextField(lastNameField)
        Utilities.styleTextField(usernameField)
        Utilities.styleTextField(passwordField)
        Utilities.styleTextField(emailField)
        Utilities.styleFilledButton(updateButton)
    }
    
    func transitionToHome(){
        // go back to profile page or feed
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
